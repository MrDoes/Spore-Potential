# Liquids+
This mod extends the use of different liquids, slag, water, oil, cryogen, arccite and neoplasm!
For now, you can only use slag in this mod, but later I will add other liquids, including those from the planet Erekir.

Development has been frozen for a very long period of time, but I am accepting pull requests!
